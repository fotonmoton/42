void	ft_putstr(char *str);
int		ft_putchar(char c);
